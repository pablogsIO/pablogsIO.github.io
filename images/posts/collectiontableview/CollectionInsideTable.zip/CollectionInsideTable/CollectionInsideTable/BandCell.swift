//
//  BandCell.swift
//  CollectionInsideTable
//
//  Created by Pablo on 31/12/2018.
//  Copyright © 2018 Pablo Garcia. All rights reserved.
//

import UIKit

class BandCell: UITableViewCell {

    private var members = [String]()
    @IBOutlet weak var bandName: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.collectionView.register(UINib(nibName: "MembersCVCell", bundle: nil), forCellWithReuseIdentifier: "MembersId")
        collectionView.delegate = self
        collectionView.dataSource = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    public func configureCell(band: Band) {
        self.bandName.text = band.name
        self.members = band.members
    }
}

extension BandCell: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return members.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MembersId", for: indexPath) as! MembersCVCell
        
        cell.configureCell(bandMember: members[indexPath.row])

        return cell
    }
    
    
}
