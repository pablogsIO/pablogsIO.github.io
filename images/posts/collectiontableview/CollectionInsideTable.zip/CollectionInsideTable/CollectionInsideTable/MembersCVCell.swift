//
//  MembersCVCell.swift
//  CollectionInsideTable
//
//  Created by Pablo on 31/12/2018.
//  Copyright © 2018 Pablo Garcia. All rights reserved.
//

import UIKit

class MembersCVCell: UICollectionViewCell {
    
    @IBOutlet weak var bandMember: UILabel!
    
    func configureCell(bandMember: String) {
        self.bandMember.text = bandMember
    }
    
}
