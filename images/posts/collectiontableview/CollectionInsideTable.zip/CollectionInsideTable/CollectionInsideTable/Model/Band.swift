//
//  Band.swift
//  CollectionInsideTable
//
//  Created by Pablo on 31/12/2018.
//  Copyright © 2018 Pablo Garcia. All rights reserved.
//

import Foundation
import UIKit

struct Band {
    var name: String
    var image: UIImageView
    var members: [String]
}

func createModel() -> [Band] {
    
    var bands = [Band]()
    let u2 = Band(name: "U2", image: UIImageView(image: UIImage(named: "u2.jpg")), members: ["Bono", "The Edge", "Adam Clayton", "Larry Mullen"])
    bands.append(u2)
    
    let direstraits = Band(name: "Dire Straits", image: UIImageView(image: UIImage(named: "direstraits.jpg")), members: ["Mark Knopfler", "David Knopfler", "John Illsey", "Pick Withers"])
    bands.append(direstraits)
    
    let rollingstones = Band(name: "The Beatles", image: UIImageView(image: UIImage(named: "rollingstones.jpg")), members: ["John Lennon", "Paul McCartney", "George Harrison", "Ringo Starr"])
    bands.append(rollingstones)
    
    let thepolice = Band(name: "The Police", image: UIImageView(image: UIImage(named: "thepolice.jpg")), members: ["Sting", "Andy Summers", "Steward Coppeland"])
    bands.append(thepolice)
    
    let queen = Band(name: "Queen", image: UIImageView(image: UIImage(named: "queen")), members: ["Freddy Mercury", "Brian May", "John Deacon", "Roger Taylor"])
    bands.append(queen)
    
    let ledzeppelin = Band(name: "Led Zeppelin", image: UIImageView(image: UIImage(named: "ledzeppelin")), members: ["Robert Plant", "Jimmy Page", "John Paul Jones", "John Bonham"])
    bands.append(ledzeppelin)
    
    return bands
}



